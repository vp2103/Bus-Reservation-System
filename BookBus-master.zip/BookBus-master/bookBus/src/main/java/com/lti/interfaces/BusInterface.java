package com.lti.interfaces;

import com.lti.entity.BusDetails;

public interface BusInterface {
 
	public void addBuses(BusDetails bus) throws Exception; 
}
