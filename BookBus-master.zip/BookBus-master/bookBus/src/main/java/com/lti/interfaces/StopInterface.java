package com.lti.interfaces;

import com.lti.entity.Stops;

public interface StopInterface {

	public int  addStops(Stops stop) throws Exception;
}
