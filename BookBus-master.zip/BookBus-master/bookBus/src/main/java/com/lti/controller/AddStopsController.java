package com.lti.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.lti.entity.City;
import com.lti.entity.Stops;
import com.lti.service.AddStopsService;
import com.lti.service.LoginService;

@Controller
public class AddStopsController {

	

}
