package com.lti.interfaces;

import com.lti.entity.User;


public interface UserInterface {

	public int register(User user);
}
